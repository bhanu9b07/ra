#!/bin/bash
sudo $(dirname $0)/python_sudo_helper.sh "$@"
