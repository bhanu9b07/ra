#!/bin/bash
export PYTHONPATH=$(dirname $0)/../
/usr/bin/python "$@"
